<?php

	global $wpdb;

	$table_name = $wpdb->prefix . "member";

	$info=$_REQUEST["info"];

	if($info=="saved")
	{
		echo "<div class='updated' id='message'><p><strong>Member Added</strong>.</p></div>";
	}

	if($info=="upd")
	{
		echo "<div class='updated' id='message'><p><strong>Record Updated</strong>.</p></div>";
	}

	if($info=="del")
	{
		$delid=$_GET["did"];
		$wpdb->query("delete from ".$table_name." where id=".$delid);
		echo "<div class='updated' id='message'><p><strong>Record Deleted.</strong>.</p></div>";
	}

?>

<script type="text/javascript">
	/* <![CDATA[ */
	jQuery(document).ready(function(){
		jQuery('#memberlist').dataTable();
	});
	/* ]]> */

</script>


<div class="wrap">
    <h2>List of Records <a class="button add-new-h2" href="admin.php?page=member_add&act=add">Add New</a></h2>
	 <table class="wp-list-table widefat fixed " id="memberlist" border="1">
		<thead>
			<tr>
				
				<th><u>First Name</u></th>
				<th><u>Last Name</u></th>
				<th><u>Mobile</u></th>
				<th><u>Home Phone</u></th>
				<th><u>Agent Name</u></th>
				<th><u>Edit Customer</u></th>
				<th><u>Delete Customer</u></th>
				<th><u>View Caes</u></th>
			</tr>
		</thead>
		<tbody>
		
<?php global $wpdb;
		$sql = "select * from ".$table_name." order by id desc";
		
		$result = $wpdb->get_results($sql); 

		if (count($result) > 0 )
		{

		?>
				<script type="text/javascript">
				/* <![CDATA[ */
				jQuery(document).ready(function(){
					jQuery('#mytable').dataTable();
				});
				/* ]]> */

				</script>

<?php

			foreach ($result as $row )
			{
				$id        = $row->id;
				$fname  = $row->fname;
				$lname      = $row->lname;
				$mobile   = $row->mobile;
				$phome       = $row->phome;
				$user_info       = $row->user_info;
	?>
			<tr>
				<td nowrap><?php echo $fname; ?></td>
				<td nowrap><?php echo $lname; ?></td>
				<td><?php echo $mobile; ?></td>
				<td><?php echo $phome; ?></td>
				<td><?php echo $user_info; ?></td>
				<td><u><a href="admin.php?page=member_add&act=upd&id=<?php echo $id;?>">Edit</a></u></td>
				<td><u><a href="admin.php?page=myplug/muyplg.php&info=del&did=<?php echo $id;?>">Delete</a></u></td>
				<td><u><a href="admin.php?page=show_case&mamber_id=<?php echo $id;?>">View all Case</a></u></td>
			</tr>
<?php }
	} else { ?>
			<tr>
				<td>No Record Found!</td>
			<tr>
	<?php } ?>
	</tbody>
	</table>
</div>