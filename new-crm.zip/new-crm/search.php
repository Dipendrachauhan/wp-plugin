<?php
 ob_start();
    define('_HOST_NAME', 'localhost');
    define('_DATABASE_USER_NAME', 'root');
    define('_DATABASE_PASSWORD', '');
    define('_DATABASE_NAME', 'wordpress');
 
    $dbConnection = new mysqli(_HOST_NAME, _DATABASE_USER_NAME, _DATABASE_PASSWORD, _DATABASE_NAME);
    if ($dbConnection->connect_error) {
        trigger_error('Connection Failed: '  . $dbConnection->connect_error, E_USER_ERROR);
    }
	
	
    if(isset($_POST['customer_name']))
    {
        $customer_name = $dbConnection->real_escape_string($_POST['customer_name']);
        $sqlCountries="SELECT * FROM wp_member WHERE fname LIKE '%$customer_name%'";
        $resCountries=$dbConnection->query($sqlCountries);
 
        if($resCountries === false) {
            trigger_error('Error: ' . $dbConnection->error, E_USER_ERROR);
        }else{
            $rows_returned = $resCountries->num_rows;
        }
 
 
 if($rows_returned > 0){
            while($rowCountries = $resCountries->fetch_assoc()) 
            { 
                echo '<div class="show"  id="my_'.$rowCountries['id'].'" align="left"><span class="country_name" >'.$rowCountries['fname'].' '.$rowCountries['lname'].'</span></div>'; 
				
            }
        }else{
            echo '<div class="show" align="left">No matching records.</div>'; 
        }
    }
ob_end_flush();
?>