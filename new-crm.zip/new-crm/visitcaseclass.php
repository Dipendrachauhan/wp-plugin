<?php
	class visitcaseclass
	{

		private $myFields=array("member_id","customer_name","agent_name","contact_type","case_note","visit_date");

		function addNewMember($tblname,$meminfo)
		{
		//print_r($meminfo); die;
			global $wpdb;
			$count = sizeof($meminfo);
			if($count>0)
			{
				$case_id=0;
				$field="";
				$vals="";

				foreach($this->myFields as $key)
				{
					if($field=="")
					{
						$field="`".$key."`";
						$vals="'".$meminfo[$key]."'";
					}
					else
					{
						$field=$field.",`".$key."`";
						$vals=$vals.",'".$meminfo[$key]."'";
					}
				}

				  $sSQL = "INSERT INTO ".$tblname." ($field) values ($vals)"; 
				$wpdb->query($sSQL);
				return true;
			}
			else
			{
				return false;
			}
		}

		function updMember($tblname,$meminfo)
		{
		
			global $wpdb;
			$count = sizeof($meminfo);
			if($count>0)
			{
				$field="";
				$vals="";
				foreach($this->myFields as $key)
				{
					if($field=="" && $key!="case_id")
					{
						$field="`".$key."` = '".$meminfo[$key]."'";
					}
					else if($key!="case_id")
					{
						$field=$field.",`".$key."` = '".$meminfo[$key]."'";
					}
				}

				$sSQL = "update ".$tblname." set $field where case_id=".$meminfo["case_id"];
				$wpdb->query($sSQL);
				return true;
			}
			else
			{
				return false;
			}
		}
		
		public function current_user_name(){
		$current_user = wp_get_current_user();
    
		return $current_user->user_login;
		
		}
	}


?>