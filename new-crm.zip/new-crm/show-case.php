<?php 

global $wpdb;

$member_table_name = $wpdb->prefix . "member";
$case_table_name = $wpdb->prefix . "visit_case";
		 $sql = "select * from ".$member_table_name." where id=".$_GET['mamber_id']." order by id desc";
		
		$member_detail = $wpdb->get_row($sql);
		echo $member_fname = $member_detail->fname;
		echo $member_lname = $member_detail->lname;

?>
<script type="text/javascript">
	/* <![CDATA[ */
	jQuery(document).ready(function(){
		jQuery('#caselist').dataTable();
	});
	/* ]]> */

</script>


<div class="wrap">
    
	 <table class="wp-list-table widefat fixed " id="caselist" border="1">
	
		<thead>
			<tr>
				<th><u>Customer Name</u></th>
				<th><u>Agent Name</u></th>
				<th><u>Contact Type</u></th>
				<th><u>Visit Case Note</u></th>
				<th><u>Visit Date</u></th>
				
			</tr>
		</thead>
		<tbody>
<?php global $wpdb;
		$sql = "select * from ".$case_table_name." where member_id=".$_GET['mamber_id']." order by case_id desc";
		
		$result = $wpdb->get_results($sql);  
		

		if (count($result) > 0 )
		{

		?>
				<script type="text/javascript">
				/* <![CDATA[ */
				jQuery(document).ready(function(){
					jQuery('#mytable').dataTable();
				});
				/* ]]> */

				</script>

<?php

			foreach ($result as $row )
			{
	
				$case_id        = $row->case_id;
				$customer_name = $row->customer_name;
				$agent_name      = $row->agent_name;
				$contact_type      = $row->contact_type;
				$case_note = $row->case_note;
				$visit_date      = $row->visit_date;
	?>
			<tr>
				
				<td><?php echo $customer_name; ?></td>
				<td nowrap><?php echo $agent_name; ?></td>
				<td nowrap><?php echo $contact_type; ?></td>
				<td><?php echo $case_note; ?></td>
				<td><?php echo $visit_date; ?></td>
			</tr>
<?php }
	} else { ?>
			<tr>
				<td>No Record Found!</td>
			<tr>
	<?php } ?>
	</tbody>
	</table>
</div>