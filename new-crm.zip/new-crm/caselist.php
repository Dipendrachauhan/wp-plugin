<?php

	global $wpdb;

	$table_name = $wpdb->prefix . "visit_case";

	$info=$_REQUEST["info"];

	if($info=="saved")
	{
		echo "<div class='updated' id='message'><p><strong>Case Added</strong>.</p></div>";
	}

	if($info=="upd")
	{
		echo "<div class='updated' id='message'><p><strong>Case Updated</strong>.</p></div>";
	}

	/*if($info=="del")
	{
		$delid=$_GET["did"];
		$wpdb->query("delete from ".$table_name." where case_id=".$delid);
		echo "<div class='updated' id='message'><p><strong>Case Deleted.</strong>.</p></div>";
	}*/

?>

<script type="text/javascript">
	/* <![CDATA[ */
	jQuery(document).ready(function(){
		jQuery('#caselist').dataTable();
	});
	/* ]]> */

</script>


<div class="wrap">
    <h2>Visit Cases <span style="font-size:18px"><a href="admin.php?page=add_case&act=add">Add New Case</a></span></h2>
	 <table class="wp-list-table widefat fixed " id="caselist" border="1">
	
		<thead>
			<tr>
				<!--<th><u>Customer Name</u></th>-->
				<th><u>Customer Name</u></th>
				<th><u>Agent Name</u></th>
				<th><u>Contact Type</u></th>
				<th><u>Visit Case Note</u></th>
				<th><u>Visit Date</u></th>
				<th><u>Edit Case</u></th>
				<!--<th><u>Delete Case </u></th>-->
			
			
			</tr>
		</thead>
		<tbody>
<?php global $wpdb;
		$sql = "select * from ".$table_name." order by case_id desc";
		
		$result = $wpdb->get_results($sql);  
		

		if (count($result) > 0 )
		{

		?>
				<script type="text/javascript">
				/* <![CDATA[ */
				jQuery(document).ready(function(){
					jQuery('#mytable').dataTable();
				});
				/* ]]> */

				</script>

<?php

			foreach ($result as $row )
			{
	
				$case_id        = $row->case_id;
				$customer_name = $row->customer_name;
				$agent_name      = $row->agent_name;
				$contact_type      = $row->contact_type;
				$case_note = $row->case_note;
				$visit_date      = $row->visit_date;
	?>
			<tr>
				<!--<td><?php //echo $id; ?></td>-->
				<td><?php echo $customer_name; ?></td>
				<td nowrap><?php echo $agent_name; ?></td>
				<td nowrap><?php echo $contact_type; ?></td>
				<td><?php echo $case_note; ?></td>
				<td><?php echo $visit_date; ?></td>
				<td><u><a href="admin.php?page=add_case&act=upd&id=<?php echo $case_id;?>">Edit</a></u></td>
				<!--<td><u><a href="admin.php?page=visit_case&info=del&did=<?php echo $case_id;?>">Delete</a></u></td>-->
			</tr>
<?php }
	} else { ?>
			<tr>
				<td>No Record Found!</td>
			<tr>
	<?php } ?>
	</tbody>
	</table>
</div>
