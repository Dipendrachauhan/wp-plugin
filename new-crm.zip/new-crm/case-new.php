<?php ob_start();?>
<script type="text/javascript" src="//code.jquery.com/jquery-1.8.0.min.js"></script>
<script type="text/javascript">
$(function(){
$(".customer_name").keyup(function() 
{ 
    var customer_name_value = $(this).val();
    var dataString = 'customer_name='+ customer_name_value;
    if(customer_name_value!='')
    {
        $.ajax({
            type: "POST",
            url: "http://localhost:8081//wordpress/wp-content/plugins/new-crm/search.php",
            data: dataString,
            cache: false,
            success: function(html)
                {
                    $("#result").html(html).show();
					alert("sgdfdgfhfhghh");
                }
        });
    }
    return false;    
});

$(".show").live("click",function(e){
  var contentPanelId = jQuery(this).attr("id");
  var customerId = contentPanelId.split('_')[1];
  var customer_name = jQuery(this).children('span').html();
 jQuery('#customer_name_id').val(customer_name);
 jQuery('#member_id').val(customerId);
  
    
});
 
$(document).live("click", function(e) { 
    var $clicked = $(e.target);
    if (! $clicked.hasClass("customer_name")){
        $("#result").fadeOut(); 
    }
});
 
$('#customer_name_id').click(function(){
    $("#result").fadeIn();
});
});
</script>

<?php
	require_once("visitcaseclass.php");
	$objMemcase = new visitcaseclass();
	$addme1=$_POST["addme1"];
	global $wpdb;
    
	$act=$_REQUEST["act"];
	if($act=="upd")
	{
		$recid=$_REQUEST["id"];
		global $wpdb;
		 $sSQL="select * from ".$table_name = $wpdb->prefix . "visit_case where case_id=$recid";
		
		$row = $wpdb->get_row($sSQL,ARRAY_A); 
		
		if (count($row) > 0 )
		{
			
			    $case_id        = $row['case_id'];
			    $member_id        = $row['member_id'];
				$customer_name        = $row['customer_name'];
				$agent_name      = $row['agent_name'];
				$contact_type      = $row['contact_type'];
				$case_note = $row['case_note'];
				$visit_date      = $row['visit_date'];
				
				$btn	   = "Update Case";
				$hidval	   = 2;
			
		}
		
	}
	else
	{
		
		
		$btn	   ="Add New Case" ;
		$case_id = "";
		$member_id = "";
		$customer_name  = "";
		$agent_name  = "";
		$contact_type  = "";
		$case_note = "";
		$visit_date = "";
		
		$hidval	   = 1;
	}
	 
?>

<div class="visit_case">
	
	<h3><?php echo $btn;  ?></h3>

	<form class="validate" action="admin.php?page=add_case" method="post" id="addtag">
	
			<div class="col-xs-12 col-sm-12 col-md-12">
				
				<div class="col-xs-12 col-sm-12">
				<div class="col-xs-12 col-sm-4"><label>Customer Name: </label><br/>
				<input type="text" name="customer_name" class="customer_name" id="customer_name_id" placeholder="Customer name" value="<?php echo $customer_name;?>" required autocomplete="off"/>
				<div id="result"></div>
				<input type="hidden" name="member_id" class="member_id" id="member_id" value="<?php echo $member_id;?>" placeholder="Customer name" required />
				<div id="result"></div>
				</div>
				<div class="col-xs-12 col-sm-4">
				<label>Contact Type:</label>
				<select class="for-ui" id="ctype" name="contact_type" required>
				<option value="">Select Type</option>
				<option value="Visit" <?php if($contact_type == 'Visit'){ ?>selected<?php } ?>>Visit</option>
				<option value="E-mail" <?php if($contact_type == 'E-mail'){ ?>selected<?php } ?>>E-mail</option>
				<option value="Phone Call" <?php if($contact_type == 'Phone Call'){ ?>selected<?php } ?>>Phone Call</option>
				<option value="Fax" <?php if($contact_type == 'Fax'){ ?>selected<?php } ?>>Fax</option>
				</select></div>	
				<div class="col-xs-12 col-sm-4"><label>Visit Case Note: </label>
				<textarea placeholder="Visit Case Note" class="for-ui" id="case_note" name="case_note" required/><?php echo $case_note; ?></textarea>
				</div>
				</div>
					
				<div class="col-xs-12 col-sm-12">
				<div class="col-xs-12 col-sm-4"><label>Visit Date:</label>
				<input readonly class="for-ui" id="vcdate" name="visit_date" type="text" value="<?php echo date('Y-m-d');?>" size="30" required></div>
				<?php if($act=="upd")
			{ ?>
				<div class="col-xs-12 col-sm-4">
				<label>Agent Name:</label>
				<input readonly class="for-ui" id="agent" name="agent_name" type="text" value="<?php echo $agent_name; ?>" size="30" required>
				
				</div>
			<?php } else {?>
				<div class="col-xs-12 col-sm-4">
				<label>Agent Name:</label>
				<input readonly class="for-ui" id="agent" name="agent_name" type="text" value="<?php echo $objMemcase->current_user_name(); ?>" size="30" required>
				
				</div>
			<?php } ?>
				
				<div class="col-xs-12 col-sm-2"><label>&nbsp;</label></div>
				<div class="col-xs-12 col-sm-4"><input type="submit" value="<?php echo $btn; ?>" class="for-ui" id="submit_case" name="submit_case"/></div>
				</div>
							
			</div>

					<p class="submit">
						<input type="hidden" name="addme1" value=<?php echo $hidval;?> >
						<input type="hidden" name="case_id" value=<?php echo $case_id;?> >
					</p>
	</form>

</div>