<?php
/*
Plugin Name: New CRM
Description: This plugin used for add edit delete and listing module at admin side. Also user can search and sort records.
Version: 1.0
Author: Dipendra

*/


require_once("memberclass.php");
require_once("visitcaseclass.php");
$objMem = new memberClass();
$objMemcase = new visitcaseclass();

$table_name = $wpdb->prefix . "member";
 
function addmyplug() {

    global $wpdb;
    global $db_version;
	 
	$table_name = $wpdb->prefix . "member";
	$MSQL = "show tables like '$table_name'";
	 
	$table_name1 = $wpdb->prefix . "visit_case";
	$MSQL1 = "show tables like '$table_name1'";
	 
    $charset_collate = $wpdb->get_charset_collate();

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

	if($wpdb->get_var($MSQL) != $table_name && $wpdb->get_var($MSQL1) != $table_name1)
	{
    $sql ="CREATE TABLE IF NOT EXISTS $table_name (
		  id mediumint(9) NOT NULL AUTO_INCREMENT,
		  fname varchar(255) DEFAULT NULL,
		  lname varchar(255) NOT NULL,
		  desire_date date NOT NULL,
		  living_status varchar(255) NOT NULL,
		  follow_up_date date NOT NULL,
		  rlreason varchar(255) NOT NULL,
		  phome int(11) NOT NULL,
		  mobile int(11) NOT NULL,
		  pbusiness int(11) NOT NULL,
		  fax int(11) NOT NULL,
		  address varchar(255) NOT NULL,
		  city varchar(255) NOT NULL,
		  state varchar(255) NOT NULL,
		  zip varchar(255) NOT NULL,
		  country varchar(255) NOT NULL,
		  user_info varchar(255) NOT NULL,
		  PRIMARY KEY (id)
		  ) $charset_collate;";

    dbDelta( $sql );

		 $sql="CREATE TABLE IF NOT EXISTS $table_name1 ( 
         case_id mediumint(9) NOT NULL AUTO_INCREMENT,
         member_id mediumint(9) NOT NULL,
		 customer_name varchar(100) NOT NULL,
		 agent_name varchar(100) NOT NULL,
		 contact_type varchar(255) NOT NULL,
		 case_note varchar(255) NOT NULL,
		 visit_date date NOT NULL, 
		 PRIMARY KEY (case_id)
         ) $charset_collate;";
		 
    dbDelta($sql);

    add_option("db_version", $db_version);
	}
}	
	

	/* Hook Plugin */
	register_activation_hook(__FILE__,'addmyplug');


	/* Creating Menus */
	function member_Menu()
	{

		/* Adding menus */
		add_menu_page(__('CRM'),'CRM', 8,'myplug/muyplg.php', 'member_list');

		/* Adding Sub menus */
		add_submenu_page('myplug/muyplg.php', 'Add Customer', 'Add Customer', 8, 'member_add', 'member_add');
		add_submenu_page('myplug/muyplg.php', 'Visit Cases', 'Visit Cases', 8, 'visit_case', 'visit_case');
		add_submenu_page('myplug/muyplg.php', 'Add Case', 'Add Case', 8, 'add_case', 'add_case');
		add_submenu_page('myplug/muyplg.php', 'Show Cases', null, 8, 'show_case', 'show_case');
		
		
	wp_register_style('demo_table.css', plugin_dir_url(__FILE__) . 'css/demo_table.css');
	wp_enqueue_style('demo_table.css');
	wp_register_style('bootstrap.css', plugin_dir_url(__FILE__) . 'css/bootstrap.css');
	wp_enqueue_style('bootstrap.css');	
	wp_register_style('dhtmlgoodies_calendar.css', plugin_dir_url(__FILE__) . 'css/dhtmlgoodies_calendar.css');
	wp_enqueue_style('dhtmlgoodies_calendar.css');	
	wp_register_style('custom.css', plugin_dir_url(__FILE__) . 'css/custom.css');
	wp_enqueue_style('custom.css');
	
	
	wp_register_script('bootstrap.js', plugin_dir_url(__FILE__) . 'js/bootstrap.js', array('jquery'));
	wp_enqueue_script('bootstrap.js');
	
	wp_register_script('dhtmlgoodies_calendar.js', plugin_dir_url(__FILE__) . 'js/dhtmlgoodies_calendar.js', array('jquery'));
	wp_enqueue_script('dhtmlgoodies_calendar.js');	
	
	wp_register_script('jquery.dataTables.js', plugin_dir_url(__FILE__) . 'js/jquery.dataTables.js', array('jquery'));
	wp_enqueue_script('jquery.dataTables.js');
	
	}


add_action('admin_menu', 'member_Menu');


function member_list() {
	include "memberlist.php";
}


function member_add() {
	include "member-new.php";
}


function visit_case() {
	include "caselist.php";
}


function show_case() {
	include "show-case.php";	
	
}

function add_case() {
	include "case-new.php";	
	
}

if(isset($_POST["submit_case"]) )
{ 


	if($_POST["addme1"] == "1")
	{

		$objMemcase->addNewMember($table_name = $wpdb->prefix . "visit_case",$_POST);
		
		header("Location:admin.php?page=visit_case&info=saved");
		exit;
	}
	else if($_POST["addme1"] == "2")
	{
	
		$objMemcase->updMember($table_name = $wpdb->prefix . "visit_case",$_POST);
		header("Location:admin.php?page=visit_case&info=upd");
		exit;
	}
}

if(isset($_POST["submit"]))
{

	if($_POST["addme"] == "1")
	{
	
	$_POST['rlreason'] = implode(',',$_POST['rlreason']);
    
		$objMem->addNewMember($table_name = $wpdb->prefix . "member",$_POST);
		header("Location:admin.php?page=myplug/muyplg.php&info=saved");
		exit;
	}
	else if($_POST["addme"] == "2")
	{
	    $_POST['rlreason'] = implode(',',$_POST['rlreason']);
		$objMem->updMember($table_name = $wpdb->prefix . "member",$_POST);
		header("Location:admin.php?page=myplug/muyplg.php&info=upd");
		exit;
	}
}

?>