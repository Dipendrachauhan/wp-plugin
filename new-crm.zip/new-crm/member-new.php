<?php
	require_once("memberclass.php");
	$objMem = new memberClass();
 global $current_user;
		get_currentuserinfo();
	$addme=$_POST["addme"];
	global $wpdb;

	$act=$_REQUEST["act"];
	if($act=="upd")
	{
		$recid=$_REQUEST["id"];
		global $wpdb;
		$sSQL="select * from ".$table_name = $wpdb->prefix . "member where id=$recid";
		$row = $wpdb->get_row($sSQL,ARRAY_A); 
		
		if (count($row) > 0 )
		{
		
			
				$id        = $row['id'];
				$fname      = $row['fname'];
				$lname      = $row['lname'];
				$desire_date = $row['desire_date'];
				$living_status      = $row['living_status'];
				$follow_up_date      = $row['follow_up_date'];
				$rlreason      = explode(',',$row['rlreason']);
				$phome      = $row['phome'];
				$mobile      = $row['mobile'];
				$pbusiness      = $row['pbusiness'];
				$fax      = $row['fax'];
				$address      = $row['address'];
				$city      = $row['city'];
				$state      = $row['state'];
				$zip      = $row['zip'];
				$country      = $row['country'];
				$user_info  = $row['user_info'];
				$btn	   = "Update Customer";
				$hidval	   = 2;
			
		}
	}
	else
	{
		$btn	   ="Add New Customer";
		$id = "";
		$fname = "";
		$lname  = "";
		$desire_date = "";
		$living_status  = "";
		$follow_up_date = "";
		$rlreason      = [];
		$phome      = "";
		$mobile      = "";
		$pbusiness      = "";
		$fax      = "";
		$address      = "";
		$city      = "";
		$state      = "";
		$zip      = "";
		$country      = "";
		$hidval	   = 1;
	}

	if($act=="upd")
	{
?>
	<h3>Edit Customer</h3>
	<?php } else  { ?>
	<h3>Add New Customer</h3>
	<?php } ?>

			<form class="validate" action="admin.php?page=member_add" method="post" id="addtag">
			<div class="new_member">
			<div class="col-sm-12">
			<div class="col-sm-4"><label>First Name:</label><br/>
			<input  id="fname" name="fname" type="text" value="<?php echo $fname; ?>" size="30" required/>
			</div>
			
			<div class="col-sm-4">
			<label>Last Name:</label><br />
			<input  id="lname" name="lname" type="text" value="<?php echo $lname; ?>" size="30" required/>
			</div>
			
			<div class="col-sm-4">
			<label>Date Needed Desired Move-In Date:</label><br/>
			<input id="datepicker" class="datepicker" type="text" type="text" value="<?php echo $desire_date; ?>" readonly name="desire_date" size="30" onFocus="displayCalendar(document.forms[0].desire_date,'yyyy/mm/dd',this)" required>
			</div>
			</div>
				
			<div class="col-sm-12">
			<div class="col-sm-4">
			<label>Current Living Status:</label><br/>
			<select id="living_statuss" name="living_status" required>
			<option value="">Select</option>
			<option value="renting" <?php if($living_status == 'renting'){ ?>selected<?php } ?>>Renting</option>
			<option value="renter" <?php if($living_status == 'renter'){ ?>selected<?php } ?>>First Time Renter</option>
			<option value="parents" <?php if($living_status == 'parents'){ ?>selected<?php } ?>>Living With Parents</option>
			<option value="owner" <?php if($living_status == 'owner'){ ?>selected<?php } ?>>Home Owner</option>
			</select>
			</div>
			
			<div class="col-sm-4">
			<label>Result Reason:</label><br />
			<select id="rlreason" name="rlreason[]" multiple="multiple" required>
			<option>Select</option>
			<option value="leased" <?php if(in_array('leased',$rlreason)){ ?>selected<?php } ?> >Leased</option>
			<option value="unqualified" <?php if(in_array('unqualified',$rlreason)){ ?>selected<?php } ?>>Unqualified</option>
			<option value="leasing" <?php if(in_array('leasing',$rlreason)){ ?>selected<?php } ?>>High Prob of Leasing</option>
			<option value="competition" <?php if(in_array('competition',$rlreason)){ ?>selected<?php } ?>>Lost 2 Competition</option>
			<option value="expensive" <?php if(in_array('expensive',$rlreason)){ ?>selected<?php } ?>>.. too Expensive</option>
			<option value="location" <?php if(in_array('location',$rlreason)){ ?>selected<?php } ?>>..Location</option>
			
			</select>
			</div>
			
			<div class="col-sm-4">
			<label>Scheduled Follow-Up Date:</label><br />
			<input id="follow_up_date" class="datepicker" type="text" value="<?php echo $follow_up_date; ?>" readonly name="follow_up_date" size="30" onFocus="displayCalendar(document.forms[0].follow_up_date,'yyyy/mm/dd',this)" required>
			</div>
			</div>
			
			<h4>Contact Details</h4>
						
			<div class="col-sm-12">
			<div class="col-sm-4">
			<label>Home (Phone No.):</label><br/>
			<input  id="home" name="phome" type="number" value="<?php echo $phome; ?>" size="30" required/>
			</div>
			
			<div class="col-sm-4">
			<label>Mobile No.:</label><br />
			<input  id="mobile" name="mobile" type="number" value="<?php echo $mobile; ?>" size="30" required/>
			</div>
			<div class="col-sm-4">
			<label>Business (Phone No.):</label><br />
			<input  id="business" name="pbusiness" type="number" value="<?php echo $pbusiness; ?>" size="30" required/>
			</div>
			
			<div class="col-sm-4">
			<label>Fax No.:</label><br />
			<input id="fax" name="fax" type="number" value="<?php echo $fax; ?>" size="30" required/>
			</div>
			
			<?php
			if($act=="upd")
			{ ?>
			
			<div class="col-sm-4">
			<label>Added By:</label><br />
			<input readonly id="user_info" name="user_info" type="text" value="<?php echo $user_info ?>" size="30" required/>
			</div>
			
			<?php } else { ?>
			<div class="col-sm-4">
			<label>Added By:</label><br />
			
			<input readonly id="user_info" name="user_info" type="text" value="<?php echo $current_user->user_login; ?>" size="30" required/>
			</div>	
			<?php 	
			} ?>
			</div>
			
			<h4>Address</h4>
			
			<div class="col-sm-12">
			<div class="col-sm-4">
			<label>Street:</label><br/>
			<input  id="address" name="address" type="text" value="<?php echo $address; ?>" size="30" required/>
			</div>
			
			<div class="col-sm-4">
			<label>City:</label><br />
			<input  id="city" name="city" type="text" value="<?php echo $city; ?>" size="30" required/>
			</div>
			
			<div class="col-sm-4">
			<label>State:</label><br />
			<input  id="state" name="state" type="text" value="<?php echo $state; ?>" size="30" required/>
			</div>
			
			<div class="col-sm-4">
			<label>Zip Code:</label><br />
			<input  id="zip" name="zip" type="number" value="<?php echo $zip; ?>" size="30" required/>
			</div>
			
			<div class="col-sm-4">
			<label>Country:</label><br />
			<input  id="country" name="country" type="text" value="<?php echo $country; ?>" size="30" required/>
			
			</div>
			
			<div class="col-sm-4"><label></label>
			<input type="submit" value="<?php echo $btn; ?>" class="button" id="submit" name="submit"/>
			</div>
				
			</div>
			
			
					<p class="submit">
						<input type="hidden" name="addme" value=<?php echo $hidval;?> >
						<input type="hidden" name="id" value=<?php echo $id;?> >
					</p>
			</form>
			</div>
		